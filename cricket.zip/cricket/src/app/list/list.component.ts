import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CricketService } from '../app.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  userdata: any;
  pagination:number;
  page_number:any=[];
  page_select:number = 0;
  
  constructor(private http: HttpClient,private appService:CricketService,private route: ActivatedRoute) { }


  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    if(id==null) {
      this.getUser();
      this.getPaginationCount();
    }
    else {
    this.getPaginationUser(id);
    this.getPaginationCount();
    }
  }
  getPaginationCount() {
    return this.appService.getPlayerCount().subscribe(
      data=>{
        this.pagination =Math.ceil(data/4);
        for(let i=0;i<this.pagination;i++){
            this.page_number.push(i);
        }
      },
      error=>console.log(error)
    )
  }
  getPaginationUser(id) {
    this.getPaginationCount();
    return this.appService.getPlayerByPagination(id).subscribe(data => {
      this.userdata = data;
      this.page_select = id;
    }, error => { console.log("Server error"); }
    );
  }
  getUser() {
    return this.appService.getPlayer().subscribe(data => {
      this.userdata = data;
      
    }, error => { console.log("Server error"); }
    );

  }

  previousPage(id){
    this.page_select = id;
    this.getPaginationUser(id-1); 
  }

  nextPage(id){
    this.page_select = id;
    this.getPaginationUser(id+1); 
  }

  deletePlayer(id,name){
    var r = confirm("Are you sure want user :"+name+"("+id+")");
    if (r == true) {
      this.appService.deletePlayer(id).subscribe(data => {
        this.userdata = data;
      }, error => { console.log("Server error"); }
      );
      // location.reload();
    } 
   
  }

 
}
