import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CricketService } from '../app.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {
  userdata:any;
  next:Number;
  
  constructor(
    private http: HttpClient,
    private appService:CricketService,
    private route: ActivatedRoute
    ) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
   
    this.getUser(id);
  }
  getUser(id) {
    return this.appService.getPlayerById(id).subscribe(data => {
      this.next =  parseInt(id)+1;
      this.userdata = data;
      
      console.log(this.userdata);
    }, error => { console.log("Server error"); }
    );

  }

}
