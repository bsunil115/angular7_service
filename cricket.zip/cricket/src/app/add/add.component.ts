import { Component, OnInit } from '@angular/core';
import { CricketService } from '../app.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit {
  submitted: boolean;
  model = {
    "name":'',
    "country":'',
    "role":'',
    "file_upload":''
  };

  constructor(private appService:CricketService) {

    new FormControl(this.model.name || '', [Validators.required, this.noWhitespaceValidator]);

   }

  ngOnInit() {
  }

  public noWhitespaceValidator(control: FormControl) {
    console.log(control.value);
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
}

// tslint:disable-next-line: no-unused-expression
  
onSubmit() { 
    this.submitted = true;
    console.log(JSON.stringify(this.model));
    this.appService.addPlayer(this.model).subscribe(
      (data:any)=>alert("Added Successfully"),
      error=>alert("Failed..")

    )
   }
}
