import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class CricketService {

  

constructor( private http: HttpClient) { }
base_url="http://localhost:9023/sunil/";
// tslint:disable-next-line: align
  getPlayer():any{
    return  this.http.get(this.base_url);
  }

  getPlayerById(id: number):any{
    console.log(id);  
    return  this.http.get(this.base_url+'view/'+id);
  }

  getPlayerByPagination(id: number):any{
    console.log(id);  
    return  this.http.get(this.base_url+'list/'+id);
  }

  getPlayerCount():any{
    
    return  this.http.get(this.base_url+'list/');
  }

  addPlayer(data: any):any{
    console.log(data);  
    return  this.http.post(this.base_url+'add/',data);
  }

  updatePlayer(data: any):any{
    console.log(data);  
    return  this.http.post(this.base_url+'add/',data);
  }

  deletePlayer(id: number):any{
    return  this.http.get(this.base_url+'delete/'+id);
  }
  
}