import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CricketService } from '../app.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {

  // model = {
  //   "name":'',
  //   "country":'',
  //   "role":'',
  //   "file_upload":''
  // };
  model = [];
  submitted: boolean;
  dispaly:any;
  userdata: any;
  constructor(private http: HttpClient,private appService:CricketService,private route: ActivatedRoute,) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    let view = this.route.snapshot.data['view'];
    this.dispaly = view;
 

    if(view=='0')
      this.getUserData();
    else
      this.getUser(id)

  }
  getUserData() {
    return this.appService.getPlayer().subscribe(data => {
      this.userdata = data;
      
    }, error => { console.log("Server error"); }
    );

  }
  getUser(id) {
   
    return this.appService.getPlayerById(id).subscribe(data => {
      this.model= data;
      console.log(this.model);
    }, error => { console.log("Server error"); }
    );

  }
  getUserSelect(id) {
    this.dispaly ='1';
    this.dispaly ='a';
    this. getUser(id);

  }
  onSubmit() { 
    this.submitted = true;
    console.log(JSON.stringify(this.model));
    this.appService.updatePlayer(this.model).subscribe(
      (data:any)=>alert("Updated Successfully"),
      error=>alert("Failed..")

    )
   }


}
