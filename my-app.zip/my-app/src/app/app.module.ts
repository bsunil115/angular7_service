import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ModalComponent } from './_modaldirectives';
import { AppComponent } from './app.component';
import { ModalService } from './_modalservice';
import { HomeComponent } from './home';
import { FormsModule }    from '@angular/forms';
import { routing }        from './app.routing';
@NgModule({
  declarations: [
    AppComponent,
    ModalComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    routing
    
  ],
  providers: [
    ModalService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
