import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ModalService } from './_modalservice';
import { Observable } from 'rxjs/internal/Observable';


import './content/app.less';
import './content/modal.less';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'my-app';
  user_data = {};
  userdata: any;
  public users$: Observable<null>;

  constructor(private http: HttpClient, private modalService: ModalService) { }

  // tslint:disable-next-line: use-life-cycle-interface
  ngOnInit() {
    this.getUser();
    // this.users$ =  this.getUser();
  }

  openModal(id: string,uid:any) {
    this.user_data = uid;
    console.log(this.user_data);
    this.modalService.open(id);
  }

  closeModal(id: string) {
    this.modalService.close(id);
  }

  getUser() {
    return this.http.get('http://localhost:8080/test/').subscribe(data => {
      this.userdata = data;
      console.log(this.userdata);
    }, error => { console.log("Server error"); }
    );

  }

  deleteUser(id:number) {
     console.log(id);   
    return this.http.get('http://localhost:8080/test/del/'+id).subscribe(data => {
      this.userdata = data;
      console.log(this.userdata);
    }, error => { console.log("Server error"); }
    );

  }


}
